## Craft HR

HR Management System adhering to UAE Labour Law

#### License

MIT