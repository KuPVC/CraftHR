# Copyright (c) 2024, Craftinteractive and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestDocumentRequestForm(FrappeTestCase):
	pass
