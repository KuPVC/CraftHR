# Copyright (c) 2023, Craftinteractive and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCraftHRSettings(FrappeTestCase):
	pass
