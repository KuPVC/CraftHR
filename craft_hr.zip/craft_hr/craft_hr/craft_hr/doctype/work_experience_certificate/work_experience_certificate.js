// Copyright (c) 2024, Craftinteractive and contributors
// For license information, please see license.txt

frappe.ui.form.on('Work Experience Certificate', {
	// refresh: function(frm) {

	// }
});
