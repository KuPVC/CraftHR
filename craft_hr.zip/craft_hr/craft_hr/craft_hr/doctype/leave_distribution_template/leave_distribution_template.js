// Copyright (c) 2023, Craftinteractive and contributors
// For license information, please see license.txt

frappe.ui.form.on('Leave Distribution Template', {
	// refresh: function(frm) {

	// }
});
