from frappe import _

def get_data():
	return [
		{
			"module_name": "Craft HR",
			"type": "module",
			"label": _("Craft HR")
		}
	]
